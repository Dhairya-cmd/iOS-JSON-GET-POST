//
//  DisplayViewController.swift
//  DbDemo
//
//  Created by Dhairya Upadhyaya on 13/10/22.
//

///If Using API Then Replace URL With The API URL Otherwise Use The Database URL

import UIKit

class DisplayViewController: UIViewController {
    
    @IBOutlet weak var lblname: UILabel!
    
    @IBOutlet weak var lblsurname: UILabel!
    
    @IBOutlet weak var lblcity: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
        var iname = [String]()
        var isurname = [String]()
        var icity = [String]()
        
        func show_data()
        {
            let myUrl = URL(string: "https://akhiya.000webhostapp.com/def.php")
            var myRequest = URLRequest(url: myUrl!)
            
            myRequest.httpMethod = "GET"
            
            let task = try! URLSession.shared.dataTask(with: myRequest)
            { (myData,URLResponse,Error) in
                
                let jsonData = try! JSONSerialization.jsonObject(with: myData!) as! [String:Any]
                
                let infoArray = jsonData["info"] as! NSArray
                
                let nameArray = infoArray.value(forKey: "name")
                self.iname = nameArray as! [String]
                print(self.iname)
                
                let surnameArray = infoArray.value(forKey: "surname")
                self.isurname = surnameArray as! [String]
                print(self.isurname)
                
                let cityArray = infoArray.value(forKey: "city")
                self.icity = cityArray as! [String]
                print(self.icity)
            }
            task.resume()
        }
}
